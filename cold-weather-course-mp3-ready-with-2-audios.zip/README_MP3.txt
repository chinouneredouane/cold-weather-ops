
Cold Weather Operations — MP3-Ready Package

• Images: use JPGs at assets/images/lessonXX.jpg (PNG fallback is automatic).
• Audio: put an MP3 per lesson at assets/audio/lessonXX.mp3.
• No autoplay: each lesson has a <audio controls> player visible to the learner.
• SCORM 1.2: use the separate SCORM zip if you need LMS tracking.

After placing MP3s, zip and deploy or import the SCORM package again so the files are included.
