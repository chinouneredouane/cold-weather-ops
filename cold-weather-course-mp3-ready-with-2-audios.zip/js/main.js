(function(){
  const totalLessons = 30;
  const body = document.body;
  const lessonIdx = parseInt(body.getAttribute('data-lesson'),10) || null;

  function getVisited(){ try { return JSON.parse(localStorage.getItem('visitedLessons') || '[]'); } catch(e){ return []; } }
  function setVisited(list){ localStorage.setItem('visitedLessons', JSON.stringify(Array.from(new Set(list)).sort((a,b)=>a-b))); }
  function markVisited(i){ if(!i) return; const v=getVisited(); if(!v.includes(i)){ v.push(i); setVisited(v); } }
  function updateProgress(){
    const v=getVisited();
    const pct=Math.min(100, Math.round((v.length/totalLessons)*100));
    const bar=document.getElementById('progressBar');
    if(bar) bar.style.width=pct+'%';
    const quizBtn=document.getElementById('quizBtn');
    if(quizBtn){
      if(v.length>=totalLessons){ quizBtn.classList.add('primary'); quizBtn.textContent='Take Quiz (unlocked)'; }
      else { quizBtn.textContent=`Take Quiz (after lessons — ${v.length}/${totalLessons})`; }
    }
  }

  function setupAudioBlock(){
    const audioEl = document.getElementById('narration');
    const statusEl = document.getElementById('audioStatus');
    const dl = document.getElementById('downloadAudio');
    if(!audioEl || !statusEl) return;
    statusEl.textContent = 'Looking for lesson audio…';
    function ok(){
      statusEl.textContent = 'Audio ready. Click play to listen.';
      if(dl) dl.style.display = 'inline-block';
    }
    function no(){
      statusEl.textContent = 'No audio found for this lesson yet. Place the MP3 at the path shown.';
      if(dl) dl.style.display = 'none';
    }
    audioEl.addEventListener('loadeddata', ok);
    audioEl.addEventListener('error', no);
    // If it loaded quickly, the readyState may already be > 0
    setTimeout(()=>{
      if(audioEl.readyState > 0) ok();
    }, 300);
  }

  if(lessonIdx){ markVisited(lessonIdx); }
  updateProgress();
  window.addEventListener('DOMContentLoaded', setupAudioBlock);

  // Fallback: if a .jpg lesson image is missing, try .png of same name
  document.addEventListener('error', function(e){
    const t = e.target;
    if(t.tagName === 'IMG' && t.src.endsWith('.jpg')){
      t.src = t.src.replace('.jpg','.png');
    }
  }, true);
})();